//
//  PUUICCDCVC.h
//  PayUNonSeamlessTestApp
//
//  Created by Umang Arya on 30/12/15.
//  Copyright © 2015 PayU. All rights reserved.
//

#import "PUUIBaseVC.h"

@interface PUUICCDCVC : PUUIBaseVC <UITextFieldDelegate>

@property (nonatomic, strong) NSString *paymentType;

@end
