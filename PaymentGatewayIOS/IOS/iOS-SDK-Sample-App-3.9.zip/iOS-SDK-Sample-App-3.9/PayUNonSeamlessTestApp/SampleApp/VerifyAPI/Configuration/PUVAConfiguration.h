//
//  PUVAConfiguration.h
//  PayUNonSeamlessTestApp
//
//  Created by Umang Arya on 4/11/16.
//  Copyright © 2016 PayU. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PUVAConfiguration : NSObject

@property NSArray *arrAPIName;
@property (strong, nonatomic) NSString *salt;

@end
