//
//  PUVAOptionsVC.h
//  PayUNonSeamlessTestApp
//
//  Created by Umang Arya on 4/11/16.
//  Copyright © 2016 PayU. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PUUIBaseVC.h"

@interface PUVAOptionsVC : PUUIBaseVC

@property (strong, nonatomic) NSString *salt;

@end
