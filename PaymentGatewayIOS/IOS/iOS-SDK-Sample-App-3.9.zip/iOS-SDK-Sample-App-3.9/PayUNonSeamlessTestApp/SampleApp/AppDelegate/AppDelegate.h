//
//  AppDelegate.h
//  PayUNonSeamlessTestApp
//
//  Created by Umang Arya on 26/12/15.
//  Copyright © 2015 PayU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

