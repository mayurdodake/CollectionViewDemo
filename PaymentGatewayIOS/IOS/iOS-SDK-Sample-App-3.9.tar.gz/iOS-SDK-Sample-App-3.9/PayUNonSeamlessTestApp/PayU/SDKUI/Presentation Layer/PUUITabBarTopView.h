//
//  PUUITabBarTopView.h
//  PayUNonSeamlessTestApp
//
//  Created by Arun Kumar on 29/12/15.
//  Copyright © 2015 PayU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PUUITabBarTopView : UIView

@property(nonatomic, weak) IBOutlet UILabel *lblAmount;
@property(nonatomic, weak) IBOutlet UILabel *lblTxnID;


@end
