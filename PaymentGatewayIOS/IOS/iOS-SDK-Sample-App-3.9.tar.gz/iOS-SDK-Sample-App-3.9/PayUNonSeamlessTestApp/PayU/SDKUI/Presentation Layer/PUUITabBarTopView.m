//
//  PUUITabBarTopView.m
//  PayUNonSeamlessTestApp
//
//  Created by Arun Kumar on 29/12/15.
//  Copyright © 2015 PayU. All rights reserved.
//

#import "PUUITabBarTopView.h"

@implementation PUUITabBarTopView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
