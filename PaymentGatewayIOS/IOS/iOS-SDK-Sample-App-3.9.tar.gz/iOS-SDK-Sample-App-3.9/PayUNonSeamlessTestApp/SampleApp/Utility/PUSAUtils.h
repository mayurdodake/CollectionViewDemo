//
//  PUSAUtils.h
//  PayUNonSeamlessTestApp
//
//  Created by Umang Arya on 5/2/16.
//  Copyright © 2016 PayU. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PUSAUtils : NSObject

+(NSURLRequest *)getNSURLRequestForLocalBankSimulator;

@end
